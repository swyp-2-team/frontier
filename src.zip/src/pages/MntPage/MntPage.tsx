export default function MntPage() {
  return <div>관리 페이지</div>;
}

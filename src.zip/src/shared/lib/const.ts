export const MOCK_CREDENTIALS = {
  id: "testuser",
  password: "password123",
};

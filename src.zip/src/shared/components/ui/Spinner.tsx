import { BeatLoader } from "react-spinners";

export default function Spinner() {
  return (
    <BeatLoader color="#ed8a30" className="self-center justify-self-center" />
  );
}
